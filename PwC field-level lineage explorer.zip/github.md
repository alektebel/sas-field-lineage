repo: alektebel/sas-field-lineage
branch: main

## Last sync

date: 2026-09-09T14:52:00Z

### Updated in this project

- Adapted the SAS field-lineage concept into a visual PwC-palette explorer: register-level graph with upstream/downstream tracing.
- Added the repo's field-evaluation idea as a "value run": minimal required inputs per field, contract-cycle CSV/Excel upload, value shown at every hop.
- Added zoom with naive layer clustering when zoomed out and field-level detail when zoomed in.
- Added a low-key `.sas` / `.egp` / `.txt` import that stages parsed DATA/PROC/assignment counts as candidate lineage.

## Screen map

| Screen | Repo files |
| --- | --- |
| Lineage Explorer.dc.html — graph + field trace | README.md, docs/FEATURES.md (AST field lineage, upstream/downstream query) |
| Lineage Explorer.dc.html — value run panel | docs/FEATURES.md (Field Evaluation: manual entry, CSV/Excel import) |
| Lineage Explorer.dc.html — SAS import strip | README.md (SAS parser: DATA steps, PROC steps, assignments) |
